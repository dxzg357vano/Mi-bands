const CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
const LOOKUP = new Uint8Array(256)
for (let i = 0; i < CHARS.length; i++) {
  LOOKUP[CHARS.charCodeAt(i)] = i
}

export function base64ToUint8Array(base64) {
  let bufferLength = Math.floor(base64.length * 0.75)
  const len = base64.length
  if (base64[len - 1] === '=') {
    bufferLength--
    if (base64[len - 2] === '=') {
      bufferLength--
    }
  }

  const bytes = new Uint8Array(bufferLength)
  let p = 0

  for (let i = 0; i < len; i += 4) {
    const encoded1 = LOOKUP[base64.charCodeAt(i)]
    const encoded2 = LOOKUP[base64.charCodeAt(i + 1)]
    const encoded3 = LOOKUP[base64.charCodeAt(i + 2)]
    const encoded4 = LOOKUP[base64.charCodeAt(i + 3)]

    bytes[p++] = (encoded1 << 2) | (encoded2 >> 4)
    if (p < bufferLength) {
      bytes[p++] = ((encoded2 & 15) << 4) | (encoded3 >> 2)
    }
    if (p < bufferLength) {
      bytes[p++] = ((encoded3 & 3) << 6) | (encoded4 & 63)
    }
  }
  return bytes
}
