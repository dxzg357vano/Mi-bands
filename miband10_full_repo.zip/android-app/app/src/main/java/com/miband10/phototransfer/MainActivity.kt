package com.miband10.phototransfer

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private lateinit var transferManager: BandTransferManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        transferManager = BandTransferManager(this)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                PhotoSenderScreen(transferManager)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        transferManager.stopBleServer()
    }

    @Composable
    fun PhotoSenderScreen(manager: BandTransferManager) {
        var connectionStatus by remember { mutableStateOf("Инициализация Bluetooth...") }
        var selectedUri by remember { mutableStateOf<android.net.Uri?>(null) }
        var processedImage by remember { mutableStateOf<ProcessedImage?>(null) }
        var selectedPreset by remember { mutableStateOf(QualityPreset.HD_ZOOM_2X) }
        var cropToFill by remember { mutableStateOf(false) }
        var isSending by remember { mutableStateOf(false) }
        var progress by remember { mutableIntStateOf(0) }

        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {
            manager.startBleServer()
        }

        LaunchedEffect(Unit) {
            manager.onConnectionStateChanged = { _, msg ->
                connectionStatus = msg
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                permissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.BLUETOOTH_ADVERTISE,
                        Manifest.permission.BLUETOOTH_SCAN
                    )
                )
            } else {
                manager.startBleServer()
            }
        }

        // Автоматический пересчет сжатия при смене фото или режима четкости
        LaunchedEffect(selectedUri, selectedPreset, cropToFill) {
            val uri = selectedUri ?: return@LaunchedEffect
            withContext(Dispatchers.IO) {
                runCatching {
                    ImageProcessor.processUri(this@MainActivity, uri, selectedPreset, cropToFill)
                }.onSuccess {
                    processedImage = it
                }
            }
        }

        val photoPickerLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.PickVisualMedia()
        ) { uri ->
            if (uri != null) {
                selectedUri = uri
            }
        }

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF0F172A)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Mi Band 10 Фото-Передатчик",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = connectionStatus,
                    fontSize = 13.sp,
                    color = Color(0xFF38BDF8)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Превью в пропорциях капсульного экрана Mi Band 10 (212x520)
                Box(
                    modifier = Modifier
                        .width(150.dp)
                        .height(340.dp)
                        .background(Color.Black, RoundedCornerShape(75.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    val img = processedImage
                    if (img != null) {
                        Image(
                            bitmap = img.previewBitmap.asImageBitmap(),
                            contentDescription = "Preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Text(
                            text = "Экран\n212×520",
                            color = Color(0xFF64748B),
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                processedImage?.let { img ->
                    val kb = img.bytes.size / 1024
                    Text(
                        text = "Готово к отправке: $kb КБ (${img.width}×${img.height})",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Переключатель детализации для зума на часах
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    QualityPreset.entries.forEach { preset ->
                        FilterChip(
                            selected = selectedPreset == preset,
                            onClick = { selectedPreset = preset },
                            label = { Text(preset.label.substringBefore(" ("), fontSize = 12.sp) }
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = cropToFill,
                        onCheckedChange = { cropToFill = it }
                    )
                    Text(
                        text = "Заполнить весь экран (без полей)",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                if (isSending) {
                    LinearProgressIndicator(
                        progress = { progress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Передача на часы: $progress%",
                        color = Color(0xFF38BDF8),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // КНОПКА 1: Выбрать фото
                Button(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    enabled = !isSending,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("1. Выбрать картинку из галереи", fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // КНОПКА 2: Отправить на браслет
                Button(
                    onClick = {
                        val img = processedImage ?: return@Button
                        isSending = true
                        progress = 0
                        lifecycleScope.launch {
                            val ok = manager.sendImage(
                                title = "Фото ${System.currentTimeMillis() % 10000}",
                                image = img,
                                onProgress = { p -> progress = p }
                            )
                            isSending = false
                            Toast.makeText(
                                this@MainActivity,
                                if (ok) "Отправлено на Mi Band 10!" else "Ошибка передачи",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    enabled = processedImage != null && !isSending,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("2. Отправить на Mi Band 10", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
