package com.miband10.phototransfer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import java.io.ByteArrayOutputStream
import kotlin.math.min

enum class QualityPreset(
    val label: String,
    val targetWidth: Int,
    val targetHeight: Int,
    val jpegQuality: Int
) {
    STANDARD_1X("1× Эконом (212×520)", 212, 520, 80),
    HD_ZOOM_2X("2× HD для зума (424×1040)", 424, 1040, 78),
    TEXT_SHARP_3X("3× Мелкий текст (636×1560)", 636, 1560, 82)
}

data class ProcessedImage(
    val bytes: ByteArray,
    val previewBitmap: Bitmap,
    val width: Int,
    val height: Int
)

object ImageProcessor {

    fun processUri(
        context: Context,
        uri: Uri,
        preset: QualityPreset,
        cropToFill: Boolean
    ): ProcessedImage {
        // Шаг 1: Читаем габариты без загрузки огромного фото в ОЗУ телефона
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, boundsOptions)
        }

        // Шаг 2: Декодируем с безопасным inSampleSize
        val sampleSize = calculateInSampleSize(
            boundsOptions.outWidth,
            boundsOptions.outHeight,
            preset.targetWidth,
            preset.targetHeight
        )
        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val rawBitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, decodeOptions)
        } ?: throw IllegalStateException("Не удалось открыть изображение")

        // Шаг 3: Вписываем (Fit) или заполняем (Center-Crop) под холст Mi Band 10
        val outBitmap = Bitmap.createBitmap(
            preset.targetWidth,
            preset.targetHeight,
            Bitmap.Config.RGB_565
        )
        val canvas = Canvas(outBitmap)
        canvas.drawColor(Color.BLACK)

        val scaleX = preset.targetWidth.toFloat() / rawBitmap.width
        val scaleY = preset.targetHeight.toFloat() / rawBitmap.height
        val scale = if (cropToFill) maxOf(scaleX, scaleY) else min(scaleX, scaleY)

        val dx = (preset.targetWidth - rawBitmap.width * scale) / 2f
        val dy = (preset.targetHeight - rawBitmap.height * scale) / 2f

        val matrix = Matrix().apply {
            postScale(scale, scale)
            postTranslate(dx, dy)
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(rawBitmap, matrix, paint)
        if (rawBitmap != outBitmap) {
            rawBitmap.recycle()
        }

        // Шаг 4: Сжимаем в легкий JPEG
        val bos = ByteArrayOutputStream()
        outBitmap.compress(Bitmap.CompressFormat.JPEG, preset.jpegQuality, bos)
        val jpegBytes = bos.toByteArray()

        return ProcessedImage(
            bytes = jpegBytes,
            previewBitmap = outBitmap,
            width = preset.targetWidth,
            height = preset.targetHeight
        )
    }

    private fun calculateInSampleSize(
        rawW: Int,
        rawH: Int,
        reqW: Int,
        reqH: Int
    ): Int {
        var inSampleSize = 1
        if (rawH > reqH || rawW > reqW) {
            val halfH = rawH / 2
            val halfW = rawW / 2
            while ((halfH / inSampleSize) >= reqH && (halfW / inSampleSize) >= reqW) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }
}
