package com.miband10.phototransfer

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import android.content.Intent
import android.os.ParcelUuid
import android.util.Base64
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.UUID
import kotlin.math.ceil

@SuppressLint("MissingPermission")
class BandTransferManager(private val context: Context) {

    companion object {
        val SERVICE_UUID: UUID = UUID.fromString("00001888-0000-1000-8000-00805f9b34fb")
        val CHAR_DATA_UUID: UUID = UUID.fromString("00001889-0000-1000-8000-00805f9b34fb")
        val CHAR_ACK_UUID: UUID = UUID.fromString("0000188a-0000-1000-8000-00805f9b34fb")
        val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private var gattServer: BluetoothGattServer? = null
    private var connectedWatch: BluetoothDevice? = null
    private var dataCharacteristic: BluetoothGattCharacteristic? = null
    private var ackDeferred: CompletableDeferred<Int>? = null

    var onConnectionStateChanged: ((Boolean, String) -> Unit)? = null

    fun startBleServer() {
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            ?: return
        val adapter: BluetoothAdapter = btManager.adapter ?: return
        if (!adapter.isEnabled) {
            onConnectionStateChanged?.invoke(false, "Включите Bluetooth на телефоне")
            return
        }

        gattServer = btManager.openGattServer(context, gattServerCallback)
        val service = BluetoothGattService(
            SERVICE_UUID,
            BluetoothGattService.SERVICE_TYPE_PRIMARY
        )

        dataCharacteristic = BluetoothGattCharacteristic(
            CHAR_DATA_UUID,
            BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_READ,
            BluetoothGattCharacteristic.PERMISSION_READ
        ).apply {
            addDescriptor(
                BluetoothGattDescriptor(
                    CCCD_UUID,
                    BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE
                )
            )
        }

        val ackCharacteristic = BluetoothGattCharacteristic(
            CHAR_ACK_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )

        service.addCharacteristic(dataCharacteristic)
        service.addCharacteristic(ackCharacteristic)
        gattServer?.addService(service)

        val advertiser = adapter.bluetoothLeAdvertiser
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setConnectable(true)
            .setTimeout(0)
            .build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(ParcelUuid(SERVICE_UUID))
            .build()

        advertiser?.startAdvertising(settings, data, object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                onConnectionStateChanged?.invoke(false, "Готов к отправке (Interconnect + BLE активен)")
            }
        })
    }

    fun stopBleServer() {
        try {
            gattServer?.close()
        } catch (_: Exception) {}
        gattServer = null
    }

    private val gattServerCallback = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectedWatch = device
                onConnectionStateChanged?.invoke(true, "Браслет подключен (${device.address})")
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                if (connectedWatch?.address == device.address) {
                    connectedWatch = null
                    onConnectionStateChanged?.invoke(false, "Браслет отключился")
                }
            }
        }

        override fun onDescriptorWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            descriptor: BluetoothGattDescriptor,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray
        ) {
            if (responseNeeded) {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
            }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice,
            requestId: Int,
            characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean,
            responseNeeded: Boolean,
            offset: Int,
            value: ByteArray
        ) {
            if (responseNeeded) {
                gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
            }
            if (characteristic.uuid == CHAR_ACK_UUID && value.size >= 2) {
                val seq = (value[0].toInt() and 0xFF) or ((value[1].toInt() and 0xFF) shl 8)
                ackDeferred?.complete(seq)
            }
        }
    }

    /**
     * Отправляет подготовленную картинку чанками:
     * - Если браслет подключен напрямую по BLE GATT, передает бинарные пакеты с ожиданием ACK.
     * - Одновременно транслирует JSON-пакеты для моста Interconnect (Notify for Xiaomi / Xiaomi Wear).
     */
    suspend fun sendImage(
        title: String,
        image: ProcessedImage,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val watch = connectedWatch
        val dataChar = dataCharacteristic

        if (watch != null && dataChar != null && gattServer != null) {
            // BLE GATT передача (по 180 байт полезной нагрузки в пакете для совместимости с любым MTU)
            val chunkSize = 180
            val totalChunks = ceil(image.bytes.size.toDouble() / chunkSize).toInt()

            // 1. Заголовок (Flag = 1)
            val header = ByteArray(9)
            header[0] = 1
            header[1] = 0
            header[2] = 0
            header[3] = (totalChunks and 0xFF).toByte()
            header[4] = ((totalChunks shr 8) and 0xFF).toByte()
            val size = image.bytes.size
            header[5] = (size and 0xFF).toByte()
            header[6] = ((size shr 8) and 0xFF).toByte()
            header[7] = ((size shr 16) and 0xFF).toByte()
            header[8] = ((size shr 24) and 0xFF).toByte()

            if (!sendBlePacketWithAck(watch, dataChar, header, 0)) return@withContext false

            // 2. Потоковая отправка чанков (Flag = 2)
            for (seq in 1..totalChunks) {
                val start = (seq - 1) * chunkSize
                val end = minOf(start + chunkSize, image.bytes.size)
                val len = end - start
                val packet = ByteArray(3 + len)
                packet[0] = 2
                packet[1] = (seq and 0xFF).toByte()
                packet[2] = ((seq shr 8) and 0xFF).toByte()
                System.arraycopy(image.bytes, start, packet, 3, len)

                if (!sendBlePacketWithAck(watch, dataChar, packet, seq)) return@withContext false
                onProgress((seq * 100) / totalChunks)
            }

            // 3. Финальный пакет (Flag = 3)
            val endPacket = byteArrayOf(3, 0, 0)
            dataChar.value = endPacket
            gattServer?.notifyCharacteristicChanged(watch, dataChar, false)
            onProgress(100)
            return@withContext true
        } else {
            // Передача по протоколу Interconnect (Base64-фрагменты по 3072 байта)
            val rawChunkSize = 3072
            val totalChunks = ceil(image.bytes.size.toDouble() / rawChunkSize).toInt()

            val headerJson = JSONObject().apply {
                put("type", "header")
                put("title", title)
                put("totalBytes", image.bytes.size)
                put("totalChunks", totalChunks)
                put("width", image.width)
                put("height", image.height)
            }
            broadcastInterconnectMessage(headerJson.toString())

            for (seq in 1..totalChunks) {
                val start = (seq - 1) * rawChunkSize
                val end = minOf(start + rawChunkSize, image.bytes.size)
                val slice = image.bytes.copyOfRange(start, end)
                val b64 = Base64.encodeToString(slice, Base64.NO_WRAP)

                val chunkJson = JSONObject().apply {
                    put("type", "chunk")
                    put("seq", seq)
                    put("data", b64)
                }
                broadcastInterconnectMessage(chunkJson.toString())
                kotlinx.coroutines.delay(45)
                onProgress((seq * 100) / totalChunks)
            }

            val endJson = JSONObject().apply { put("type", "end") }
            broadcastInterconnectMessage(endJson.toString())
            onProgress(100)
            return@withContext true
        }
    }

    private suspend fun sendBlePacketWithAck(
        watch: BluetoothDevice,
        characteristic: BluetoothGattCharacteristic,
        payload: ByteArray,
        expectedSeq: Int
    ): Boolean {
        repeat(3) {
            val deferred = CompletableDeferred<Int>()
            ackDeferred = deferred
            characteristic.value = payload
            gattServer?.notifyCharacteristicChanged(watch, characteristic, false)
            val ack = withTimeoutOrNull(1500L) { deferred.await() }
            if (ack == expectedSeq) return true
        }
        return false
    }

    private fun broadcastInterconnectMessage(jsonPayload: String) {
        val intent = Intent("com.xiaomi.xms.wearable.INTERCONNECT_SEND").apply {
            putExtra("package", context.packageName)
            putExtra("data", jsonPayload)
        }
        context.sendBroadcast(intent)
    }
}
